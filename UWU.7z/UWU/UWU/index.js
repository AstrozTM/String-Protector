//--LUA OBFUSCATOR--\\
const FS = require('fs')
const DesktopNotifier = require('node-notifier');
const Colors = require('colors')
const { exit } = require('process');

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

let C = FS.readFileSync('./Input.lua',{encoding:'utf-8'})
String.prototype.format = function () {
    var a = this;
    for (var k in arguments) {
        a = a.replace(new RegExp("\\{" + k + "\\}", 'g'), arguments[k]);
    }
    return a
}


function ObfuscateString(Strings){
    let EncodedStrings = []
       let randomTimes=[1e9,1e8,2e3,2e6,2e7,2e5],randomTimes2=[1e9,1e8],randomTimes3=[1e9,1e8,2e3],RandomLength=[50,100,120,70,80,90,56,70],RandomLength2=[10,50,20,40,30],RandomLength3=[10,20,30,16,19,27,19],len=RandomLength[Math.floor(Math.random()*RandomLength.length)],len2=RandomLength2[Math.floor(Math.random()*RandomLength2.length)],len3=RandomLength3[Math.floor(Math.random()*RandomLength3.length)],str="";for(let o=0;o<len;o++)str+=String.fromCharCode(Math.floor(Math.random()*randomTimes[Math.floor(Math.random()*randomTimes.length)]));let str2="";for(let o=0;o<len2;o++)str2+=String.fromCharCode(Math.floor(Math.random()*randomTimes[Math.floor(Math.random()*randomTimes2.length)]));let str3="";for(let o=0;o<len3;o++)str3+=String.fromCharCode(Math.floor(Math.random()*randomTimes[Math.floor(Math.random()*randomTimes3.length)]));
       let S = Strings
       S = S.replace('"','')
       S = S.replace("'",'')
       S = S.replace('[','')
       S = S.replace(']', '')
       let EncodedString = ''
       for(let Index = 0; Index < S.length; Index++){
           let Character = S[Index]
           if(Index !== S.length){
               EncodedString = EncodedString + (`(({[[{0}]]})[1] or ({[[{1}]]})[1] or ({[[{2}]]})[1] or ({[[{3}]]})[1] or ({[[{4}]]})[1])..`.format(Character,str,str2,str3,str3))
           }
       }
       let NewString =  EncodedString.slice(0, -2)
    return NewString
}

function ReadStrings(Code){
    let BuildtString  = ''
    let StartingString = false
    let StartingLONGString = false
    let Strings = []
    for(let i = 0; i < Code.length; i++){
        // Current Characters \\
        let Character = Code[i]
       // Check if string started, or ended \\
       if(StartingString){
           if(Character == "'" || Character == '"'){
               StartingString = false
           }
       }else{
        if(Character == "'" || Character == '"'){
            StartingString = true
        }
       }
       // Scanning for strings \\
       if(StartingString){
           if(Code[i+1] == '"' || Code[i+1] == "'"){
               let UWU = Code[i+1]
               BuildtString = BuildtString + Character
               // Cleaning String \\
               BuildtString = BuildtString.replace("'",'');BuildtString = BuildtString.replace('"', '')
               Strings.push(UWU+BuildtString+UWU)
               BuildtString = ''
           }else{
               BuildtString = BuildtString + Character
           }
       }
    }
    return Strings
}



let EncodedCode = C
let A = ReadStrings(C)

for(let inde = 0;inde<A.length;inde++){
     let E = ObfuscateString(A[inde])
     E = E.replace("'",'')
     E = E.replace('"','')
     EncodedCode = EncodedCode.replace(A[inde],E)
}
FS.writeFileSync('./Output.lua',EncodedCode,'utf8')
console.log('Encoding...'.yellow)
DesktopNotifier.notify({
    'title' : 'Done!',
    'subtitle': 'Finished string encoder.',
    'message': 'String Protected',
    'icon': './UWU/Icons/uwu.jpg'
})

console.log('Done!'.green)