--// CODE \\--
local A ='A'
print(A)